package com.exadel.education.threading.lecture.synchronization.atomic;

/**
 * Created by Sergey Derugo
 * Date: 2/21/12
 * Time: 3:41 AM
 */
public interface Counter {

    public abstract int getValue();

    public abstract int increment();

}
